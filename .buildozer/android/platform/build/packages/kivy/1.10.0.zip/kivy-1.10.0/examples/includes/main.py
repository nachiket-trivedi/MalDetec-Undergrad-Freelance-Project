from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button


class SpecialButton(Button):
    pass


class CustomLayout(BoxLayout):
    pass


class TestApp(App):
    pass


if __name__ == '__main__':
    TestApp().run()
